

<?php

$con = mysqli_connect("localhost","root","","thesis");

$data1 = '';
$data2 = '';
$date = '';
$sql = "SELECT * FROM `chart` ";
$result = mysqli_query($con, $sql);

while ($row = mysqli_fetch_array($result)) {
    $data1 = $data1.'"'. $row['data1'].'",';
    $data2 = $data2.'"'. $row['data2'].'",';
    $date = $date.'"'. $row['date'].'",';
    
}

$date = trim($date,",");
$data1 = trim($data1,",");
$data2 = trim($data2,",");
?>

<!DOCTYPE html>
<html>
<head>

<meta name="wiewport" content="width=device-width, initial-scale=1.0">

<script type="text/javascript" src="js/Chart.bundle.min.js"></script>
<script type="text/javascript" src="js/Chart.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.bundle.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<title>Chart</title>

<style type="text/css">
body{
    font-family: Arial;
    margin: 120px 100px 10px 100px;
    padding:0;
    color:white;
    text-align: center;
    background: white;
}
.container{
    color: #E8E9EB;
    background: whitesmoke;
    border: #555652 1px solid;
    padding: 10px;
}
</style>

</head>
<body>
        <div class="container">
        <h1>chart</h1>
       
        <canvas id="myChart" width="100" height="100"></canvas>
<script>
var ctx = document.getElementById("myChart").getContext('2d');
var myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: [<?php echo $date?> ],
        datasets: [{
            label: 'like',
            data: [<?php echo $data1?>],
            
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 3
          
        },
        {
            label: 'dislike',
            data: [<?php echo $data2?>],
            
            backgroundColor: [
                
                'rgba(252, 259, 164, 0.2)'
            ],
            borderColor: [
                
                'rgba(255, 123, 24, 1)'
            ],
            borderWidth: 3
        }
    
    ]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
       
    }
});
</script>
</div>  
</body>
</html>
