$(function() {
	// pusher();
	perMonth();
	// perDay();
	// perWeek();
	// getTotalOf("Wedding")
	// getTotalOf("Burial")
	// getTotalOf("Baptismal")
})


var total=[];
var labels=[];
var day = [];
var label1=[];
var week = [];
var label2=[];

function perMonth() {
	$.getJSON(`http://localhost/omo/charrt.php`,{perName:"MONTHNAME", mt:"MONTH" },function(data){

		data.map(label=>{
			labels.push(label.MONTH);
			total.push(label.COUNT);
		});
		sum( total );
		chart("myChart","bar",labels,"Monthly",total);

		console.log(data);
	});
}

function perDay(){
	$.getJSON(`${apiUrl}analytics`, {perName:"DAYNAME", mt:"DAY"}, function(data){
		data.map(label=>{
			day.push(label.DAY);
			label1.push(label.COUNT);
		});

		sum( label1 );
		chart("daily","bar",day,"Daily",label1);
	})
}

function perWeek(){
	$.getJSON(`${apiUrl}analytics`, {perName:"WEEK", mt:"WEEK"}, function(data){
		data.map(label=>{
			week.push(label.WEEK);
			label2.push(label.COUNT);
		})	
		sum( label2 );

		chart("myChart1","bar",week,"Weekly",label2);
	})
}

function sum( obj ) {
	var sum = 0;
	for( var el in obj ) {
		if( obj.hasOwnProperty( el ) ) {
			sum += parseFloat( obj[el] );
		}
	}
	// console.log(sum)
}
function getTotalOf(eventName){
	fetch(`${apiUrl}pabook_reservations/pbr_evName/${eventName}`).then(data=>data.json()).then(function(data){
		if (eventName == "Wedding") {
			document.getElementById('wed').innerHTML = data.length;
		}else if(eventName == "Baptismal"){
			document.getElementById('bap').innerHTML = data.length;
		}else{
			if (data.length == 0) {
				document.getElementById('bur').innerHTML ="No Transactions";
			}else{
				document.getElementById('bur').innerHTML = data.length;

			}
		}
	})
}




function chart(idName,chartType,labels, trans,data){
	var color;
	if (chartType == "bar") {
		color = ["rgba(54, 162, 235, 1)","#ed1c24","#f39c12","#42cdc9","#7b1211","#ed1c24","#4976ab"];
	}else{
		color = ["rgba(54, 162, 235, 1)","rgba(255,99,132,1)","rgba(255, 206, 86, 1)","rgba(75, 192, 192, 1)","rgba(153, 102, 255, 1)","rgba(255, 159, 64, 1)","rgba(100, 159, 64, 1)"];
	}
	var ctx = document.getElementById(idName).getContext('2d');
	var myChart = new Chart(ctx, {
		type: chartType,
		data: {
			labels:labels,
			datasets: [{
				label: '# of Transactions '+trans,
				data: data,
				backgroundColor: color,
				borderColor: [
				'rgba(54, 162, 235, 1)',
				'rgba(255,99,132,1)',
				'rgba(255, 206, 86, 1)',
				'rgba(75, 192, 192, 1)',
				'rgba(153, 102, 255, 1)',
				'rgba(255, 159, 64, 1)',
				'rgba(100, 159, 64, 1)'
				],
				borderWidth: 1
			}]
		},
		options: {
			maintainAspectRatio: false,
			scales: {
				yAxes: [{
					stacked: true,
					gridLines: {
						display: true,
						color: "rgba(255,99,132,0.2)"
					}
				}],
				xAxes: [{
					gridLines: {
						display: false
					}
				}]
			}
		}
	});


	setTimeout(function(){
		myChart.update();
	},1000);
}


