<!DOCTYPE html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="dante">

    <link rel="icon" type="image/png" sizes="16x16" href="images/omolavoc_icon.png">
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link href="css/lib/owl.theme.default.min.css" rel="stylesheet" />
    <link href="css/helper.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <title>OMO-LAV-OC</title>

</head>

<body class="fix-header fix-sidebar bg-primary" >
    <div class="preloader" >
        <svg class="circular" viewBox="25 25 50 50">
			<circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>
 
    <div id="main-wrapper" >

       <?php include('navbar.php');?>

        <div class="page-wrapper" style="background: url(images/bg-wall.png) no-repeat center; background-size:cover;">
            
            <div style="text-align:center;">
                <img src="images/omolavoc_v.4.0.png" alt="OMO-LAV-OC" style="height:250px; width:250px; margin-top:20px;">
            </div>

            <div style="text-align:center;">
                <h2>Web Beta version (v.0.0.1)</h2>
                
                <div style="width:80%; margin-left:auto; margin-right:auto;">
                    <p style="color:#e0e0e0; font-size:13px;">
                        OMO-LAV-OC is an mobile(android) based application that will let the citizens
                        of olongapo to write their concern to any form of iregularity regarding an specific
                        departments but also to write a positive feedback on that specific departments.
                        people can also react to every tourist spots inside Olongapo City as additional
                        feature of the mobile app to gather more opinions from olongapenyos.
                    </p>
                </div>

                <hr style="width:80%; margin-left:auto; maring-right:auto;"/>

                <h2>Omolavoc mobile application system info.</h2>

                <br/>

                <div style="width:80%; margin-left:auto; margin-right:auto; border-radius:20px 20px 20px 20px;">
                    <div style="column-count:2; background-color:#00000020;">
                        <ul>
                            <li style="padding:10px; color:#00000070;"><b>App Version :</b></li>
                            <li style="padding:10px;">v.0.1.0</li>
                        </ul>
                    </div>

                    <div style="column-count:2; background-color:#00000010;">
                        <ul>
                            <li style="padding:10px; color:#00000050;"><b>Download size :</b></li>
                            <li style="padding:10px;">Atleast 30Mb</li>
                        </ul>
                    </div>

                    <div style="column-count:2; background-color:#00000020;">
                        <ul>
                            <li style="padding:10px; color:#00000070;"><b>Required OS :</b></li>
                            <li style="padding:10px;">Android 5.0 +</li>
                        </ul>
                    </div>

                    <div style="column-count:2; background-color:#00000010;">
                        <ul>
                            <li style="padding:10px; color:#00000050;"><b>Full internet access :</b></li>
                            <li style="padding:10px;">Yes</li>
                        </ul>
                    </div>

                    <div style="column-count:2; background-color:#00000020;">
                        <ul>
                            <li style="padding:10px; color:#00000070;"><b>Native Feature :</b></li>
                            <li style="padding:10px;">Camera,Map,GPS</li>
                        </ul>
                    </div>

                    <div style="column-count:2; background-color:#00000010;">
                        <ul>
                            <li style="padding:10px; color:#00000050;"><b>API Flatporm :</b></li>
                            <li style="padding:10px;">ionic 3</li>
                        </ul>
                    </div>

                    <div style="column-count:2; background-color:#00000020;">
                        <ul>
                            <li style="padding:10px; color:#00000070;"><b>Landing page :</b></li>
                            <li style="padding:10px;"><a href="www.omo-landing.tk" style="color:#e0e0e0;">www.omo-landing.tk</a></li>
                        </ul>
                    </div>      

                    <div style="column-count:2; background-color:#00000010;">
                        <ul>
                            <li style="padding:10px; color:#00000050;"><b>facebook page :</b></li>
                            <li style="padding:10px;"><a href="www.omo-landing.tk" style="color:#e0e0e0;">www.facebook.com/omolavoc</a></li>
                        </ul>
                    </div>      

                    <div style="column-count:2; background-color:#00000020;">
                        <ul>
                            <li style="padding:10px; color:#00000070;"><b>PlayStore download :</b></li>
                            <li style="padding:10px;"><a href="www.omo-landing.tk" style="color:#e0e0e0;">www.google.com/playstore/omolavoc</a></li>
                        </ul>
                    </div>                    


                    <div style="background-color:#00000090; border-radius:20px 20px 20px 20px; margin-top:10%; width: 40%; margin-left:auto; margin-right:auto;">
                        <p style="color:#ffffff; font-size:10px;">©Coptyright 2019 OMOLAVOC. All rights reserved</p>
                    </div>
                </div>
            </div>
            

        </div>
    </div>

    

    <script src="js/lib/jquery/jquery.min.js"></script>
    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
    <script src="js/jquery.slimscroll.js"></script>
    <script src="js/sidebarmenu.js"></script>
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>

    <script src="js/lib/morris-chart/raphael-min.js"></script>
    <script src="js/lib/morris-chart/morris.js"></script>
    <script src="js/lib/morris-chart/dashboard1-init.js"></script>

	<script src="js/lib/calendar-2/moment.latest.min.js"></script>
    <script src="js/lib/calendar-2/semantic.ui.min.js"></script>
    <script src="js/lib/calendar-2/prism.min.js"></script>
    <script src="js/lib/calendar-2/pignose.calendar.min.js"></script>
    <script src="js/lib/calendar-2/pignose.init.js"></script>

    <script src="js/lib/owl-carousel/owl.carousel.min.js"></script>
    <script src="js/lib/owl-carousel/owl.carousel-init.js"></script>
    <script src="js/scripts.js"></script>

    <script src="js/custom.min.js"></script>

</body>

