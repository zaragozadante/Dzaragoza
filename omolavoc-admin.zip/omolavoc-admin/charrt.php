<?php

require 'db.php';

$perName = $_GET['perName'];
$name = $_GET['mt'];

$sql = $con->query("SELECT DISTINCT(data1), $perName(date) $name, COUNT(*) COUNT 
FROM chart WHERE YEAR(date)='2018' 
GROUP BY $perName(date)");

$data = array();

while($rows = mysqli_fetch_array($sql)){
    array_push($data, $rows);

}

echo json_encode($data);

?>