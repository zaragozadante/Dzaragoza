
<!DOCTYPE html>
<html>
<head>
<meta name="wiewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Content-Type" content="text/html; chartset=utf-8"/>
<link rel="stylesheet" type="text/css" href="style.css">
<script src="js/Chart.bundle.min.js"></script>
<script src="js/Chart.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<title>Chart</title>




</head>
<body>
       
        </body>
        </html>
<script>
var ctx = document.getElementById("Chart");
var data = {

    datasets: [{
        data: [2,3,55,6],
        backgroundColor: 'transparent',
        borderColor: "#45ff73",
        borderWidth: 5,
        label: 'Revenue'
    },{
        data: [22,32,12,3],
        backgroundColor: 'transparent',
        borderColor: "#9BB6ff",
        borderWidth: 5,
        label: 'Expedinture'    
    }],
    labels: [
        <2,3,4,5,12>
    ]
};

    var xChart =  new Chart(ctx, {
        type: 'line',
        data: data,
        options:{
            legend:{
                display: true,
                position: 'bottom',
                labels: {
                    fontColor:'rgb(255, 99, 132)'
                }
            },
            tooltips: {mode: 'point'  },
            scales:{
                yAxes:[{
                    ticks:{
                        autoskip: true,
                        maxTicksLimit:6
                    }
                }]
            }
        }
    }
    });
    </script>