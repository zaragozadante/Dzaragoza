<?php 

date_default_timezone_set('Asia/Manila');

echo date('l, jS F');


?>