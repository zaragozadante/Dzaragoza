<?php  
     $con = mysqli_connect("localhost","root","","thesis"); //connection to the server	   
?>
     