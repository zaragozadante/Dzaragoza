<?php
    if (isset($_POST['key'])){

        
        $conn= mysqli_connect('localhost', 'root', '', 'thesis');
        if ($_POST['key'] == 'getExistingData'){
            $start = mysqli_real_escape_string($conn, $_POST['start']);
            $limit = mysqli_real_escape_string($conn, $_POST['limit']);

            $sql =$conn->query("SELECT * FROM front where user_id LIMIT $start, $limit ");
            if ($sql->num_rows > 0) {
                $response ="";
                while($data = mysqli_fetch_array($sql)){
                    $response .= '
                    <tr>
                        <td user_id="profile_'.$data["user_id"].'">'.$data["user_id"].'</td>
                        <td>'.$data["fname"].' '.$data["lname"].'</td>
                        <td>'.$data["email"].'</td>
                        
                        <td>

                            <a href="profile-viewer.php?user_id='.$data["user_id"].'">
                            <button class="btn btn-xs btn-secondary"><i class="fa fa-eye"></i> View</button>
                            </a>                         
                            <button class="btn btn-xs btn-primary"><i class="fa fa-edit"></i> Report</button>
                            <button onclick="deleteRow('.$data["user_id"].')" value="Delete" class="btn btn-danger btn-xs"><i class="fa fa-pencil"></i> Delete</button>
                        
                        </td>
                    </tr>
                    ';
                }
                exit($response);
            } else{
                exit('reachedMax');
            }
        }
      
        if ($_POST['key'] == 'deleteRow'){
            
            $rowID = mysqli_real_escape_string($conn, $_POST['rowID']);
         
            $conn->query("DELETE FROM front WHERE user_id ='$rowID'");
            exit('The Row Has Been Deleted');
        }



    //opinion records
    if ($_POST['key'] == 'getOpinionData'){
        $start = mysqli_real_escape_string($conn, $_POST['start']);
        $limit = mysqli_real_escape_string($conn, $_POST['limit']);

        $sql =$conn->query("SELECT * FROM front where user_id  LIMIT $start, $limit ");
        if ($sql->num_rows > 0) {
            $response ="";
            while($data = mysqli_fetch_array($sql)){
                $response .= '
                <tr>
                <td  user_id="profile_'.$data["user_id"].'">'.$data["user_id"].'</td>
                    <td >'.$data["fname"].'  '.$data["lname"].'</td>
                    <td >'.$data["email"].' </td>
                              
                    
                    <td>

                        <a href="view-letter.php?user_id='.$data["user_id"].'">
                        <center><button class="btn btn-xs btn-secondary"><i class="fa fa-eye"></i> View</button></center>
                        </a>           
                        
                    </td>
                </tr>
                ';
            }
            exit($response);
        } else{
            exit('reachedMax');
        }
    }
  
    if ($_POST['key'] == 'deleteOpinionRow'){
        
        $rowID = mysqli_real_escape_string($conn, $_POST['rowID']);
     
        $conn->query("DELETE FROM opinion WHERE opinion_id ='$rowID'");
        exit('The Row Has Been Deleted');
    }

    }


    if ($_POST['key'] == 'getTouristData'){
        $start = mysqli_real_escape_string($conn, $_POST['start']);
        $limit = mysqli_real_escape_string($conn, $_POST['limit']);

        $sql =$conn->query("SELECT * FROM tourist where tourist_id order by likes desc  LIMIT $start, $limit  ");
        if ($sql->num_rows > 0) {
            $response ="";
            while($data = mysqli_fetch_array($sql)){
                $response .= '
                <tr>
                    <td tourist_id="tourist_'.$data["tourist_id"].'">'.$data["tourist_id"].'</td>
                    <td>'.$data["tname"].' </td>
                   
                    <td>'.$data["place"].'</td>
                    <td>'.$data["likes"].'</td>
                    
                    
                    <td>

                     <a href="viewspot.php?tourist_id='.$data["tourist_id"].'">
                       <center> <button class="btn btn-xs btn-secondary"><i class="fa fa-eye"></i>View</button></center>
                        </a>           
                    
                    </td>
                </tr>
                ';
            }
            exit($response);
        } else{
            exit('reachedMax');
        }
    }
  

    ?>