<!DOCTYPE html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="icon" type="image/png" sizes="16x16" href="images/omolavoc_icon.png">
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link href="css/lib/calendar2/semantic.ui.min.css" rel="stylesheet">
    <link href="css/lib/calendar2/pignose.calendar.min.css" rel="stylesheet">
    <link href="css/lib/owl.carousel.min.css" rel="stylesheet" />
    <link href="css/lib/owl.theme.default.min.css" rel="stylesheet" />
    <link href="css/helper.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <title>OMO-LAV-OC</title>

    <style>
    
    </style>
</head>

<body class="fix-header fix-sidebar bg-primary" >
    <div class="preloader" >
        <svg class="circular" viewBox="25 25 50 50">
			<circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>
 
    <div id="main-wrapper" >

       <?php include('navbar.php');?>

        <div class="page-wrapper" style="background: url(images/bg-wall.png) no-repeat center; background-size:cover;">
            
            <div class="row page-titles" style="background-color:#00000099;">
                <div class="col-md-5 align-self-center">
                    <h3 style="color:#e0e0e099;">Dashboard</h3>
                </div>

                <div class="col-md-7 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Active : 37 Users</a></li>
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Reports today : 7</a></li>
                    </ol>
                </div>
            </div>

            <div class="container-fluid">
   
                <div class="row" style="background-color:#e0e0e030; border-radius:10px 10px 10px 10px; margin-bottom:20px;">

                    <div class="col-md-6" >
                        <div class="card p-60" style="background-color:#6ead74;">
                            <div class="media">
                                <div class="media-left meida media-middle" style="background-color:#e0e0e0; padding:20px; border-radius:50px 50px 50px 50px;">
                                    <span><i class="fa fa-users f-s-60" style="color:#1d65d1;"></i></span>
                                </div>
                                <div class="media-body media-text-right">
                             
                                    <h4>10,321</h4>
                                    <h2 class="m-b-0" style="color:#e0e0e0;">Users profile</h2>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="card p-60" style="background-color:#6ead74;">
                            <div class="media">
                                <div class="media-left meida media-middle" style="background-color:#e0e0e0; padding:20px; border-radius:50px 50px 50px 50px;">
                                    <span><i class="fa fa-envelope f-s-60" style="color:#973434;"></i></span>
                                </div>
                                <div class="media-body media-text-right">
                                    <h4>11,213</h4>
                                    <h2 class="m-b-0" style="color:#e0e0e0;">Opinion Records</h2>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>




                <div class="row bg-white m-l-0 m-r-0 box-shadow ">


                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-title">
                                <h4>GAGAYAHIN KO SI JOEY </h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    
                                <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 425px;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
    </style>

    <div id="map"></div>
                                
                                <script>
                            
                                  function initMap() {
                                    var myLatLng = {lat: 14.8363041, lng: 120.2818813};
                            
                                    var map = new google.maps.Map(document.getElementById('map'), {
                                      zoom: 15,
                                      center: myLatLng
                                    });
                            
                                    var marker = new google.maps.Marker({
                                      position: myLatLng,
                                      map: map,
                                      title: 'Hello World!'
                                    });
                                  }
                                </script>   


                                </div>
                            </div>
                        </div>
                    </div>
                </div>


         
            </div>
            <!-- footer -->
            
            <!-- End footer -->
        </div>
    </div>

    <script src="js/lib/jquery/jquery.min.js"></script>
    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
    <script src="js/jquery.slimscroll.js"></script>
    <script src="js/sidebarmenu.js"></script>
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>

    <script src="js/lib/morris-chart/raphael-min.js"></script>
    <script src="js/lib/morris-chart/morris.js"></script>
    <script src="js/lib/morris-chart/dashboard1-init.js"></script>

	<script src="js/lib/calendar-2/moment.latest.min.js"></script>
    <script src="js/lib/calendar-2/semantic.ui.min.js"></script>
    <script src="js/lib/calendar-2/prism.min.js"></script>
    <script src="js/lib/calendar-2/pignose.calendar.min.js"></script>
    <script src="js/lib/calendar-2/pignose.init.js"></script>

    <script src="js/lib/owl-carousel/owl.carousel.min.js"></script>
    <script src="js/lib/owl-carousel/owl.carousel-init.js"></script>
    <script src="js/scripts.js"></script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAPxDz4bO-QBRcZOnYQ_34LlTkAEGBK00E&callback=initMap">
    </script>
    <script src="js/custom.min.js"></script>

</body>

