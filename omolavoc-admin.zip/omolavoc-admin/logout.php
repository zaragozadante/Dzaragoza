<?php
session_start();
?>
<script>
	alert("Successfully Logout!");
	document.location.href = "login.php";
</script>
<?php
unset($_SESSION['admin1']);
?>
