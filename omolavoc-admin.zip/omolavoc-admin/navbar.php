<!DOCYTYPE html>
<style>
.font-family {
    font-family:segoe-ui;
}
.navbar-color {
    /* border-bottom:solid #29802f 5px;  */
    height:90px;
    background: url(images/bg-navbar1.png);
}
.icon-sidenav {
    background-color:#1d65d140;
    text-align:center;
    padding-left:10px;
    padding-right:10px;
    padding-top:4px;
    padding-bottom:4px;
    border-radius:50px 50px 50px 50px;
    margin-right:10px;
    border:solid #29802f50 1px;
}
.icon-sidenav0 {
    background-color:#1d65d140;
    text-align:center;
    padding-top:4px;
    padding-bottom:4px;
    border-radius:50px 50px 50px 50px;
    margin-right:10px;
    border:solid #29802f50 1px;
}

</style>


<!-- ...............................................NAVBAR.............................................-->

<div class="header">
    <nav class="navbar top-navbar navbar-expand-md navbar-light navbar-color">

        <a href="omo-lav-oc.php?omo-lav-oc=1" >
            <div class="navbar-header" style="height:90px; border-bottom:solid #29802f 2px; background: url(images/bg-sidebar.png);">
                <span class="navbar-brand" style="margin-top:15px; margin-bottom:auto; "> 
                    <span><img src="images/OMOLAVOC_v.4.0.png" class="img-circle" alt="OMO-LAV-OC" width="65" height="62"> OMO-LAV-OC</span>
                </span>
            </div>
        </a>

        <div class="navbar-collapse">
            <ul class="navbar-nav mr-auto mt-md-0">     
                <li class="nav-item"> <a class="nav-link nav-toggler hidden-md-up text-muted  " href="javascript:void(0)"><i class="mdi mdi-menu"></i></a></li>
                <li class="nav-item m-l-10"> <a class="nav-link sidebartoggler hidden-sm-down text-muted  " href="javascript:void(0)"><i class="ti-menu"></i></a></li>
            </ul>
               
            <ul class="navbar-nav my-lg-0">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle text-muted  " href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="images/avatar/3.png" alt="user" class="profile-pic" /></a>
                    
                    <div class="dropdown-menu dropdown-menu-right animated zoomIn">
                        <ul class="dropdown-user">
                            <li>
                                <a href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
                            </li>
                        </ul>
                    </div>

                </li>
            </ul>

        </div>

    </nav>
</div>
       


<!-- ............................................SIDE NAVBAR..........................................-->

<div class="left-sidebar">
           
    <div class="scroll-sidebar" style="background: url(images/bg-sidebar-body1.png) no-repeat center; background-size:cover; padding-top:20px;">
    
        <nav class="sidebar-nav" style="background:none;">
            <ul id="sidebarnav">
                <li class="nav-devider"></li>
                <li class="nav-label" style="color:#29802f; font-size:15px;">Home</li>

                <li> 
                    <a href="omo-lav-oc.php?omo-lav-oc=1" aria-expanded="false"><i class="fa fa-home icon-sidenav0" style="color:#29802f;"></i><span class="hide-menu"><b>Dashboard</b></a>
                </li>

                <hr/>
                        
                <li class="nav-label" style="color:#29802f; font-size:15px;">Features</li>
                      
                <li>
                    <a  href="omo-lav-oc.php?omo-lav-oc=2" aria-expanded="false"><i class="fa fa-user icon-sidenav0" style="color:#29802f;"></i><span class="hide-menu"><b>User Profiles</b></span></a>
                </li>
                        
                <li>
                    <a  href="#" data-toggle="dropdown"  aria-expanded="false"><i class="fa fa-list icon-sidenav0" style="color:#29802f;"></i><span class="hide-menu"><b>Opinion Records   ...</b></span></a>
                    
                    <ul class="dropdown">
                        <li> <a  href="omo-lav-oc.php?omo-lav-oc=3" aria-expanded="false"><i class="fa fa-table" style="margin-right: 10px;"></i><span class="hide-menu">Opinion List</span></a></li>
                        <li> <a  href="omo-lav-oc.php?omo-lav-oc=13ad" aria-expanded="false"><i class="fa fa-list" style="margin-right: 10px;"></i><span class="hide-menu">Opinion Chart</span></a></li>
                        <li> <a  href="omo-lav-oc.php?omo-lav-oc=9" aria-expanded="false"><i class="fa fa-star" style="margin-right: 10px;"></i><span class="hide-menu">Like Chart</span></a></li>
                        <li> <a  href="omo-lav-oc.php?omo-lav-oc=10" aria-expanded="false"><i class="fa fa-star" style="margin-right: 10px;"></i><span class="hide-menu">Dislike Chart</span></a></li>
                    </ul>
                </li>

                <li>
                    <a  href="#" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-bookmark icon-sidenav0" style="color:#29802f;"></i><span class="hide-menu"><b>Olongapo Tourist   ...</b></span></a>
                    
                    <ul class="dropdown">
                        <li> <a  href="omo-lav-oc.php?omo-lav-oc=12" aria-expanded="false"><i class="fa fa-table" style="margin-right: 10px;"></i><span class="hide-menu">Tourist Spots List</span></a></li>
                        <li> <a  href="omo-lav-oc.php?omo-lav-oc=11" aria-expanded="false"><i class="fa fa-list" style="margin-right: 10px;"></i><span class="hide-menu">Tourist Spots Chart</span></a></li>
                    </ul>
                </li>
                        
                <hr/>

                <li>
                    <a  href="omo-lav-oc.php?omo-lav-oc=14" aria-expanded="false"><i class="fa fa-info icon-sidenav" style="color:#29802f;"></i><span class="hide-menu"><b>About Omolavoc</b></span></a>
                </li>
                        
                <?php if(isset($_SESSION["admin1"])): ?>
                <?php endif ?>    
            </ul>

        </nav>
    </div>
</div>