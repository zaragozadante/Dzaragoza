
<!DOCTYPE html>
<html lang="en">


    <?php
    $page = $_GET['omo-lav-oc'];
    if($page==1){
    require_once('index.php');
     }
    if($page==2){
    require_once('profiles.php');
     }
    if($page==3){
    require_once('opinion-records.php');
     }
     if($page==4){
        require_once('tourist.php');
    }
    if($page==5){
        require_once('chartomo.php');
    }
     if($page==6){
        require_once('inbox1.php');
    }
    if($page==7){
        require_once('viewspot.php');
    }
    if($page==8){
        require_once('view-letter.php');
    }
    if($page==9){
        require_once('department.php');
    }
    if($page==10){
        require_once('opinion-dislike.php');
    }
    if($page==11){
        require_once('tourist-chart.php');
    }
    if($page==12){
        require_once('tourist-report.php');
    }
    if($page==13){
        require_once('opinion-analytic.php');
    }
    if($page==14){
        require_once('about.php');
    }
    
 
?>

</html>