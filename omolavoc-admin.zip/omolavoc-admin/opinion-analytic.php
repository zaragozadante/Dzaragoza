


<?php

$con = mysqli_connect("localhost","root","","thesis");

$count1 = '';

$sql = "SELECT COUNT(*)as count1 FROM `opinion` WHERE lbody= 'Always Traffic' OR 'Many ilegal parking' ";

$result = mysqli_query($con, $sql);

while ($row = mysqli_fetch_array($result)) {
    $count1 = $count1.'"'. $row['count1'].'",';
    
}

$count1 = trim($count1,",");



$con = mysqli_connect("localhost","root","","thesis");

$count = '';

$sql = "SELECT COUNT(*)as count FROM `opinion` WHERE lbody= 'Abusing the child'  ";
$result = mysqli_query($con, $sql);

while ($row = mysqli_fetch_array($result)) {
    $count = $count.'"'. $row['count'].'",';
    
}

$count = trim($count,",");

$con = mysqli_connect("localhost","root","","thesis");

$count2 = '';

$sql = "SELECT COUNT(*)as count2 FROM `opinion` WHERE lbody= 'Crime' ";
$result = mysqli_query($con, $sql);

while ($row = mysqli_fetch_array($result)) {
    $count2 = $count2.'"'. $row['count2'].'",';
    
}

$count2 = trim($count2,",");


$con = mysqli_connect("localhost","root","","thesis");

$count3 = '';

$sql = "SELECT COUNT(*)as count3 FROM `opinion` WHERE lbody= 'Bullying the classmate'  ";
$result = mysqli_query($con, $sql);

while ($row = mysqli_fetch_array($result)) {
    $count3 = $count3.'"'. $row['count3'].'",';
    
}

$count3 = trim($count3,",");

?>


<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="icon" type="image/png" sizes="16x16" href="images/omolavoc_icon.png">
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link href="css/lib/calendar2/semantic.ui.min.css" rel="stylesheet">
    <link href="css/lib/calendar2/pignose.calendar.min.css" rel="stylesheet">
    <link href="css/lib/owl.carousel.min.css" rel="stylesheet" />
    <link href="css/lib/owl.theme.default.min.css" rel="stylesheet" />
    <link href="css/helper.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script type="text/javascript" src="js/Chart.bundle.min.js"></script>
    <script type="text/javascript" src="js/Chart.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.bundle.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <title>OMO-LAV-OC</title>
</head>

<body class="fix-header fix-sidebar">
    <div class="preloader" >
        <svg class="circular" viewBox="25 25 50 50">
			<circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>

    <div id="main-wrapper" style="background: url(images/bg-wall.png) no-repeat center; background-size:cover;">

        <?php include('navbar.php');?>

        <div class="row page-titles" style="background-color:#00000099; position:fixed; width:100%;">
                
                <div class="col-md-2 align-self-center"></div>
                <div class="align-self-center">
                    <h3 style="color:#e0e0e099; padding-left:20px;">Opinion Data Chart</h3>
                </div>
                    
                <div class="col-md-8 align-self-center">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Opinion Total : 673</a></li>
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Most Concernt : LTO</a></li>
                    </ol>
                </div>
        </div>

       
        <div class="page-wrapper" style="background:none; margin-top:90px;">
        
            <div class="container-fluid">
                <div class="card">
                
       
<canvas id="myChart" ></canvas>
<script>
var ctx = document.getElementById("myChart").getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ["For the road incident","Problem in family","Problem in Peace and Order","Problem in School" ],
        
        datasets: [{
            label: 'Records',
            
         
            data: [<?php echo $count?>,<?php echo $count1?>,<?php echo $count2?>,<?php echo $count1?>],
           
            backgroundColor: [
                
                'rgba(255, 0, 0, 0.5 )',
                'rgba(255, 0, 0, 0.5)',
                'rgba(255, 0, 0, 0.5)',
                'rgba(255, 0, 0, 0.5)'
            ],
            borderColor: [
                
                'rgba(255, 0, 0 ,1)',
                'rgba(255, 0, 0 ,1)',
                'rgba(255, 0, 0 ,1)',
                'rgba(255, 0, 0 ,1)'
            ],
            borderWidth: 0
        
            
        }        
        
    ]
    },
    
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
       
    }
});
</script>

                
                </div>
            </div>

        </div>
    </div>

    <script src="js/lib/jquery/jquery.min.js"></script>
    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
    <script src="js/jquery.slimscroll.js"></script>
    <script src="js/sidebarmenu.js"></script>
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>

    <script src="js/lib/morris-chart/raphael-min.js"></script>
    <script src="js/lib/morris-chart/morris.js"></script>
    <script src="js/lib/morris-chart/dashboard1-init.js"></script>

	<script src="js/lib/calendar-2/moment.latest.min.js"></script>
    <script src="js/lib/calendar-2/semantic.ui.min.js"></script>
    <script src="js/lib/calendar-2/prism.min.js"></script>
    <script src="js/lib/calendar-2/pignose.calendar.min.js"></script>
    <script src="js/lib/calendar-2/pignose.init.js"></script>

    <script src="js/lib/owl-carousel/owl.carousel.min.js"></script>
    <script src="js/lib/owl-carousel/owl.carousel-init.js"></script>
    <script src="js/scripts.js"></script>

    <script src="js/custom.min.js"></script>

</body>

