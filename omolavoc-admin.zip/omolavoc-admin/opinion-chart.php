


<?php

$con = mysqli_connect("localhost","root","","thesis");

$title = '';
$rating = '';
$date = '';
$sql = "SELECT * FROM `opinion` ";
$result = mysqli_query($con, $sql);

while ($row = mysqli_fetch_array($result)) {
    $title = $title.'"'. $row['title'].'",';
    $rating = $rating.'"'. $row['rating'].'",';
    $date = $date.'"'. $row['date'].'",';
    
}

$date = trim($date,",");
$title = trim($title,",");
$rating = trim($rating,",");
?>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="icon" type="image/png" sizes="16x16" href="images/omolavoc_icon.png">
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link href="css/lib/calendar2/semantic.ui.min.css" rel="stylesheet">
    <link href="css/lib/calendar2/pignose.calendar.min.css" rel="stylesheet">
    <link href="css/lib/owl.carousel.min.css" rel="stylesheet" />
    <link href="css/lib/owl.theme.default.min.css" rel="stylesheet" />
    <link href="css/helper.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script type="text/javascript" src="js/Chart.bundle.min.js"></script>
    <script type="text/javascript" src="js/Chart.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.bundle.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <title>OMO-LAV-OC</title>

</head>

<body class="fix-header fix-sidebar">
  
    <div class="preloader" >
        <svg class="circular" viewBox="25 25 50 50">
			<circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>

    <div id="main-wrapper">
       
       <?php include('navbar.php');?>
       
        <div class="page-wrapper" style="background: url(images/bg-wall.png) no-repeat center; background-size:cover;">
            <div class="container-fluid">
                <div class="card">
                <h1>Opinion Chart</h1>
      
                
<canvas id="myChart" width="500"></canvas>
<script>
var ctx = document.getElementById("myChart").getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ["Always Traffic","A robbery is happening right now","Robbery have happend just now","A person gone missing in the river","A random crime is happening right now" ],
        datasets: [{
            label: 'LTO',
            data: [33,43,45,56,45],
            
            backgroundColor: [
                
                'rgba(0, 0, 255 , 0.2)'
            ],
            borderColor: [
                
                'rgba(0, 0, 255 ,1)'
            ],
            borderWidth: 3
        
            
        }
        
        
    ]
    },
    
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
       
    }
});
</script>

                
                </div>
            </div>
 
        </div>
    </div>
    


    <script src="js/lib/jquery/jquery.min.js"></script>
    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
    <script src="js/jquery.slimscroll.js"></script>
    <script src="js/sidebarmenu.js"></script>
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>

    <script src="js/lib/morris-chart/raphael-min.js"></script>
    <script src="js/lib/morris-chart/morris.js"></script>
    <script src="js/lib/morris-chart/dashboard1-init.js"></script>

	<script src="js/lib/calendar-2/moment.latest.min.js"></script>
    <script src="js/lib/calendar-2/semantic.ui.min.js"></script>
    <script src="js/lib/calendar-2/prism.min.js"></script>
    <script src="js/lib/calendar-2/pignose.calendar.min.js"></script>
    <script src="js/lib/calendar-2/pignose.init.js"></script>

    <script src="js/lib/owl-carousel/owl.carousel.min.js"></script>
    <script src="js/lib/owl-carousel/owl.carousel-init.js"></script>
    <script src="js/scripts.js"></script>

    <script src="js/custom.min.js"></script>

</body>

