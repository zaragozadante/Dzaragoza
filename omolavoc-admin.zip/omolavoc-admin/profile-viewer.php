<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="icon" type="image/png" sizes="16x16" href="images/ereport-icon.png">
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link href="css/lib/calendar2/semantic.ui.min.css" rel="stylesheet">
    <link href="css/lib/calendar2/pignose.calendar.min.css" rel="stylesheet">
    <link href="css/lib/owl.carousel.min.css" rel="stylesheet" />
    <link href="css/lib/owl.theme.default.min.css" rel="stylesheet" />
    <link href="css/helper.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    
    <title>e-Report</title>

<!--CSS start here-->
    <style>
    .font-family {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    .text {
        background-color:brown;
        font-size: 20px;
        display: table-cell;
        vertical-align: middle;

    }
    .form {
        width:100%;
        text-align: center;
    }
    .colum-count-3 {
        column-count: 3;
    }
    .column-count-2 {
        column-count: 2;
    }
    .navbar {
        padding-left:30px;
        padding-top:30px;
        padding-bottom:30px;
        column-count: 3;
        box-shadow: 0px 10px 10px 0px #00000030;
        background-color:#ffffff;
    }
    .nav-logo {
        font-weight: 50px;
    }
    .img {
        border:solid #3e6394 3px;
        margin-top:5%;
        margin-bottom:10%;
        height: 250px;
        width: 250px;
        object-fit: cover;
        box-shadow: 0px 10px 10px 0px #00000030;
        border-radius: 150px 150px 150px 150px;
    }
    .div-normal {
        background:none;
        width:100%;
    }
    .text-align-right {
        margin-top:0px;
        text-align: right;
      
    }
    .text-align-left {
        padding-top: 3px;
        text-align: left;
    }
    th {
        text-align: right;
    }
    .table-ui {
        width:90%;
        margin-left:auto;
        margin-right:auto;
        margin-top:40px;
    }
    .table-content {
        color:#333333;
        background-color: #ffffff70;
        padding-top:15px;
        padding-bottom:15px;
        padding-right: 40px;
    }
    .th-content {
        color:#ffffff;
        font-weight:bold; 
        background-color: #6ead7499;
        padding-top:10px;
        padding-bottom:10px;
        padding-right: 40px;
    }
    .radius-top-left {
        border-radius: 10px 0px 0px 0px;
    }
    .radius-top-right {
        border-radius: 0px 10px 0px 0px;
    }
    .radius-bottom-left {
        border-radius: 0px 0px 0px 10px;
    }
    .radius-bottom-right {
        border-radius: 0px 0px 10px 0px;
    }
    h1 {
        color:#333333;
        font-weight:bold;
        font-size:60px;
        text-shadow:0px 3px 7px #00000060;
    }
    h2 {
        color:#333333;
        font-size: 30px;
    }

    .footer {
        color:#ffffff;
        text-align: center;
        background-color: #0e6d99;
        height: 50px;
    }
    .tab {
        margin-left:20px;

    }
    .text-tab {
        font-size: 20px;
        color:#33333390;
    }
    hr {
        border:none;
        background-color:#33333370;
        opacity: 10;
        height:1px;
        width:90%;
    }
    .card-ui {
        max-width:90%;
        border-radius:50px 50px 50px 50px;
        border-top:solid #3c649b 5px;
        margin-top:2%;
        margin-left:auto;
        margin-right:auto;
        padding-bottom:10px;
        background-color:#5885c1;
    }
    .card-division {
        column-count:2 ;
    }
    .card-header {
        padding-left:20px;
        padding-left:20px;
        border-radius:0px 0px 0px 50px;
        column-count:3 30%;
        background-color:black;
    }
    .card-right-content {
        border-radius:0px 50px 0px 0px;
        background-color:#3333330;
    }
    .card-map {
        background:no-repeat center; background-size:cover;
        border:none;
        height:150px;
        width:150px;
        border-radius:50%;
        margin-top:2%;
        margin-left:5%;
        margin-right:auto;
        border:solid #3e6394 3px;
    }
    .card-thumbnail {
        background:no-repeat center; background-size:cover;
        border:none;
        height:150px;
        width:200px;
        border-radius:20px 20px 20px 20px;
        margin-top:2%;
        margin-left:5%;
        margin-right:auto;
        border:solid #3e6394 3px;
    }
    .card-header-title {
        margin-left:30px;
        font-weight:bold;
        font-size:20px;
    }
    .a-float-right {
        margin-right:40px;
        float:right;
    }
    .a-float-left {
        padding-bottom:1px;
        margin-right:40px;
        float:left;
    }
    .card-body {
        color:#ffffff80;
        padding-top:20px;
        padding-left:30px;
    }
    .card-body-sub {
        color:#ffffff50;
        padding-top:10px;
        padding-left:30px;
    }
    .card-date {
        font-size:12px;
    }
    .card-button {
        margin-top:5%;
        font-weight:bold;
        padding-left:30px;
        padding-top:10px;
        padding-bottom:10px;
        padding-right:30px;
        border-radius:50px 50px 50px 50px;
        background-color:#3c649b;
    }
    .card-button:hover {
        margin-top:5%;
        font-weight:bold;
        padding-left:30px;
        padding-top:10px;
        padding-bottom:10px;
        padding-right:30px;
        border-radius:50px 50px 50px 50px;
        background-color:#3c649b90;
    }

</style>

</head>

<body class="fix-header fix-sidebar bg-primary">
    <div class="preloader" >
        <svg class="circular" viewBox="25 25 50 50">
		    <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10">
        </svg>
    </div>

    <div id="main-wrapper" >
 
        <?php include('navbar.php');?>
       
        <div class="page-wrapper" style="background: url(images/bg-wall.png) no-repeat center; background-size:cover;">
            <div>
                    <section>
                        <form class='form'>
                            <div class='div-normal'>
                                <img class="img" alt="profile picture" src="images/0.gif"/>
                            </div>

                            <div>
                                <h1 style="color:#ffffff;">James Arthur Burgch</h1>
                            </div>

                            <div>
                                <table class='table-ui'>
                                    <tr>
                                        <th class='th-content radius-top-left'>Username</th>
                                        <td class='table-content radius-top-right text-align-left'>JMjoe</td>
                                    </tr>
                                    <tr>
                                        <th class='th-content'>Gender</th>
                                        <td class='table-content text-align-left'>".$row['gender']."</td>
                                    </tr>
                                    <tr>
                                        <th class='th-content'>Age</th>
                                        <td class='table-content'>".$row['age']."</td> 
                                    </tr>
                                    <tr>
                                        <th class='th-content'>Contact</th>
                                        <td class='table-content'>".$row['contact']."</td>
                                    </tr>
                                    <tr>
                                        <th class='th-content'>e-Mail</th>
                                        <td class='table-content'>".$row['email']."</td>
                                    </tr>
                                    <tr>
                                        <th class='th-content'>Report counts</th>
                                        <td class='table-content'>13 <i>times</i></td>
                                    </tr>
                                    <tr>
                                        <th class='th-content radius-bottom-left'>Date Created</th>
                                        <td class='table-content radius-bottom-right'>April 5, 2018</td>
                                    </tr>
                                </table>
                            </div>
                        </form>
                    </section>
                 
            </div>            
        </div>
    </div>

    <script src="js/lib/jquery/jquery.min.js"></script>
    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
    <script src="js/jquery.slimscroll.js"></script>
    <script src="js/sidebarmenu.js"></script>
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="js/scripts.js"></script>
    <script src="js/custom.min.js"></script>

</body>

</html>