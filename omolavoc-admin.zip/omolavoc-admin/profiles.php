<?php
    include("db.php");  
?>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="images/omolavoc_icon.png">
    
    <link href="css/lib/bootstrap/bootstrap.min.css" rel="stylesheet">
    <link href="css/lib/calendar2/semantic.ui.min.css" rel="stylesheet">
    <link href="css/lib/calendar2/pignose.calendar.min.css" rel="stylesheet">
    <link href="css/lib/owl.carousel.min.css" rel="stylesheet" />
    <link href="css/lib/owl.theme.default.min.css" rel="stylesheet" />
    <link href="css/helper.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <title>OMO-LAV-OC</title>
</head>

<body class="fix-header fix-sidebar">
   
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
			<circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>
 
    <div id="main-wrapper">
      
        <?php include('navbar.php'); ?>
      
        <div class="page-wrapper" style="background: url(images/bg-wall.png) no-repeat center; background-size:cover;">
            
            <div class="container-fluid">
                
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="card-title">Profiles</h4>
                                <p>User list of the omo-lav-oc mobile application</p>
                                <div class="table-responsive m-t-40">
                                <table  id="dataTable "  class=" display nowrap table table-hover table-striped table-bordered" cellspacing="0" width="100%">
                                    <tbody>     
                                    <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Full Name</th>
                                                <th>e-Mail</th>
                                                <th>Action</th>
                                                
                                            </tr>
                                        </thead>
                                    
                                        </tbody>
                                    </table>     
                                    </div>
                            </div>
                        </div>

                       
                </div>
                
            </div>
           
            
          
        </div>
    </div>
   
    <script src="js/lib/jquery/jquery.min.js"></script>
    <script src="js/lib/bootstrap/js/popper.min.js"></script>
    <script src="js/lib/bootstrap/js/bootstrap.min.js"></script>
    <script src="js/jquery.slimscroll.js"></script>
    <script src="js/sidebarmenu.js"></script>
    <script src="js/lib/sticky-kit-master/dist/sticky-kit.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/lib/datatables/datatables.min.js"></script>
    <script src="js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
    <script src="js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
    <script src="js/lib/datatables/cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
    <script src="js/lib/datatables/cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
    <script src="js/lib/datatables/cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
    <script src="js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
    <script src="js/lib/datatables/cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>
    <script src="js/lib/datatables/datatables-init.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            getExistingData(0,50);
        });

    function deleteRow(rowID){
        if (confirm('Are you sure?')) {
            $.ajax({
               url: 'functions.php',
               method: 'POST',
               dataType: 'text',
               data: {
                    key: 'deleteRow',
                    rowID: rowID
               },  success: function(response){

                   $("#profile_"+rowID).parent().remove();
                   alert(response);
            }
        });

        }
    }



     function getExistingData(start, limit) {
        $.ajax({
            url: 'functions.php',
            method: 'POST',
            dataType: 'text',
            data:{
                key: 'getExistingData',
                start: start,
                limit: limit
            },  success: function (response) {
                if (response != "reachedMax") {
                    $('tbody').append(response);
                    start +=limit;
                    getExistingData(start, limit);
                }else 
                    $(".table").DataTable();
//for table
            }

        });

    }
    </script>





</body>
