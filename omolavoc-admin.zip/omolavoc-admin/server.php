<?php 
session_start();
include 'db.php';

if(isset($_POST['submit']))
{
	$username = $_POST['username'];
	$password = $_POST['password'];
     

	$qry = "SELECT * FROM users WHERE username = '".$username."' and password = '".$password."'";
	$result = mysqli_query($con,$qry);
	$row = mysqli_fetch_array($result);
	$user =  $row['username'];
	$pass = $row['password'];

	if(mysqli_num_rows($result))
	{
		if($username == $user & $password == $pass)
		{
			$_SESSION['admin1'] = $username;
			header('location: omo-lav-oc.php?omo-lav-oc=1');		
		}
	}
	else{
	?>	
		<script>
                    alert('Invalid username or password');
                    document.location.href = 'login.php';
				</script>
			<?php			
		}
}
?>