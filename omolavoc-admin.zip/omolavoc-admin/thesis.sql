-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2019 at 12:52 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `thesis`
--

-- --------------------------------------------------------

--
-- Table structure for table `chart`
--

CREATE TABLE `chart` (
  `ID` int(11) NOT NULL,
  `data1` int(255) NOT NULL,
  `data2` int(255) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chart`
--

INSERT INTO `chart` (`ID`, `data1`, `data2`, `date`) VALUES
(1, 1, 2, '2018-12-01'),
(2, 2, 1, '2018-12-02'),
(3, 1, 3, '2018-11-03'),
(4, 1, 3, '2018-12-04'),
(5, 3, 4, '2018-12-05'),
(6, 3, 5, '2018-12-05'),
(7, 2, 1, '2018-12-06'),
(8, 2, 1, '2018-12-06'),
(9, 1, 1, '2018-12-07'),
(10, 1, 1, '2018-12-08');

-- --------------------------------------------------------

--
-- Table structure for table `front`
--

CREATE TABLE `front` (
  `user_id` int(11) NOT NULL,
  `username` varchar(250) NOT NULL,
  `fname` varchar(250) NOT NULL,
  `lname` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `kind` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `front`
--

INSERT INTO `front` (`user_id`, `username`, `fname`, `lname`, `email`, `password`, `kind`) VALUES
(1, 'test2', 'Dante', 'Zaragoza', 'dante@gmail.com', '123', ''),
(9, 'schuz', 'michael', 'shuz', 'michaelshuz@gmail.com', '123', ''),
(10, 'dante', 'joey', 'borromeo', 'borromeo@gmail.com', '123', ''),
(11, 'armand', 'armand', 'gelicame', 'gelicame@gmail.com', '123', ''),
(12, 'ss', 'ss', 'ss', 'ss@gmail.com', 'ss', ''),
(13, 'sad', 'sad', 'sad', 'sad@gmaul.cin', '123', '');

-- --------------------------------------------------------

--
-- Table structure for table `likes`
--

CREATE TABLE `likes` (
  `id` int(255) NOT NULL,
  `tourist_name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `emoji` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `likes`
--

INSERT INTO `likes` (`id`, `tourist_name`, `username`, `user_id`, `emoji`) VALUES
(289, 'subic beach', 'test2', '1', 'angry'),
(290, 'subic beach', 'test2', '1', 'dislikes'),
(291, 'Olongapo Beach', 'test2', '1', 'like'),
(292, 'test', 'test2', '1', 'like'),
(294, 'subic beach', 'michael', '8', 'like'),
(301, 'Olongapo Beach', 'test2', '1', 'heart'),
(302, 'subic beach', 'dante', '10', 'like'),
(303, 'subic beach', 'armand', '11', 'like'),
(304, 'Olongapo Beach', 'armand', '11', 'like'),
(305, 'subic beach', 'test2', '1', 'like'),
(306, 'subic beach', 'sad', '13', 'angry');

-- --------------------------------------------------------

--
-- Table structure for table `opinion`
--

CREATE TABLE `opinion` (
  `opinion_id` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `date` varchar(255) NOT NULL,
  `lbody` varchar(250) NOT NULL,
  `for` varchar(250) NOT NULL,
  `user_id` int(255) NOT NULL,
  `fb` varchar(255) NOT NULL,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `rating` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `opinion`
--

INSERT INTO `opinion` (`opinion_id`, `title`, `date`, `lbody`, `for`, `user_id`, `fb`, `fname`, `lname`, `rating`) VALUES
(64, 'LTO', 'Tuesday, 8th January', 'Always Traffic', '', 1, '', 'Dante', 'Zaragoza', 'Like'),
(65, 'PNP', 'Tuesday, 8th January', 'Crime', '', 1, '', 'Dante', 'Zaragoza', 'Like'),
(66, 'DSWD', 'Tuesday, 8th January', 'Abusing the child', '', 1, '', 'Dante', 'Zaragoza', 'Like'),
(68, 'DepEd', 'Tuesday, 8th January', 'Bullying the classmate', '', 1, '', 'Dante', 'Zaragoza', 'Like'),
(69, 'DepEd', 'Tuesday, 8th January', 'Bullying the classmate', '', 1, '', 'Dante', 'Zaragoza', 'undefined'),
(70, 'LTO', 'Tuesday, 8th January', 'Always Traffic', '', 1, '', 'Dante', 'Zaragoza', 'Like'),
(71, 'PNP', 'Tuesday, 8th January', 'Crime', '', 1, '', 'Dante', 'Zaragoza', 'Dislike'),
(72, 'DSWD', 'Tuesday, 8th January', 'Abusing the child', '', 1, '', 'Dante', 'Zaragoza', 'Dislike'),
(73, 'DSWD', 'Tuesday, 8th January', 'Abusing the child', '', 10, '', 'joey', 'borromeo', 'Dislike'),
(74, 'PNP', 'Tuesday, 8th January', 'Crime', '', 10, '', 'joey', 'borromeo', 'Dislike'),
(75, 'LTO', 'Tuesday, 8th January', 'Many ilegal parking', '', 10, '', 'joey', 'borromeo', 'Dislike'),
(76, 'DepEd', 'Tuesday, 8th January', 'Abusing the child', '', 10, '', 'joey', 'borromeo', 'Dislike'),
(77, 'LTO', 'Tuesday, 8th January', 'Always Traffic', '', 10, '', 'joey', 'borromeo', 'Dislike'),
(78, 'DepEd', 'Tuesday, 8th January', 'Bullying the classmate', '', 10, '', 'joey', 'borromeo', 'Like'),
(79, 'DepEd', 'Tuesday, 8th January', 'Bullying the classmate', '', 10, '', 'joey', 'borromeo', 'Like'),
(80, 'DepEd', 'Tuesday, 8th January', 'Bullying the classmate', '', 11, '', 'armand', 'gelicame', 'Like'),
(81, 'LTO', 'Tuesday, 8th January', 'Always Traffic', '', 11, '', 'armand', 'gelicame', 'Dislike'),
(82, 'PNP', 'Tuesday, 8th January', 'Crime', '', 11, '', 'armand', 'gelicame', 'Like'),
(83, 'DSWD', 'Tuesday, 8th January', 'Abusing the child', '', 11, '', 'armand', 'gelicame', 'Dislike'),
(84, 'LTO', 'Thursday, 17th January', ' clogged canals ', '', 1, '', 'Dante', 'Zaragoza', 'Like'),
(85, 'DepEd', 'Friday, 18th January', ' Many ilegal parking ', '', 1, '', 'Dante', 'Zaragoza', 'Like');

-- --------------------------------------------------------

--
-- Table structure for table `tourist`
--

CREATE TABLE `tourist` (
  `tourist_id` int(11) NOT NULL,
  `tname` varchar(255) NOT NULL,
  `place` varchar(255) NOT NULL,
  `rating` varchar(255) NOT NULL,
  `details` varchar(1000) NOT NULL,
  `des` varchar(255) NOT NULL,
  `likes` varchar(255) NOT NULL,
  `heart` varchar(255) NOT NULL,
  `wow` varchar(255) NOT NULL,
  `angry` varchar(255) NOT NULL,
  `dislikes` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tourist`
--

INSERT INTO `tourist` (`tourist_id`, `tname`, `place`, `rating`, `details`, `des`, `likes`, `heart`, `wow`, `angry`, `dislikes`, `img`) VALUES
(1, 'Olongapo Beach', 'Olonga city ', '3', '  This Paragraph shows the full information of the area. it could also show the the history or some exclusive detail about the area.', '', '2', '0', '0', '2', '1', './img/subic.jpg'),
(2, 'subic beach', 'Subic', '4', '  This Paragraph shows the full information of the area. it could also show the the history or some exclusive detail about the area.', '', '4', '0', '0', '2', '1', './img/nafalls.jpg'),
(5, 'Marikit Park', 'Olongapo City', '3', '  This Paragraph shows the full information of the area. it could also show the the history or some exclusive detail about the area.', '  This Paragraph shows the full information of the area. it could also show the the history or some exclusive detail about the area.', '1', '0', '1', '1', '1', './img/ulo.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(31) NOT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `position` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `position`) VALUES
(1, 'admin@gg', 'admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chart`
--
ALTER TABLE `chart`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `front`
--
ALTER TABLE `front`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `opinion`
--
ALTER TABLE `opinion`
  ADD PRIMARY KEY (`opinion_id`);

--
-- Indexes for table `tourist`
--
ALTER TABLE `tourist`
  ADD PRIMARY KEY (`tourist_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chart`
--
ALTER TABLE `chart`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `front`
--
ALTER TABLE `front`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=307;

--
-- AUTO_INCREMENT for table `opinion`
--
ALTER TABLE `opinion`
  MODIFY `opinion_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `tourist`
--
ALTER TABLE `tourist`
  MODIFY `tourist_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(31) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
