<?php

	include 'db.php';
	

    if(isset($_POST['submit']) ) {
   
	$ran = rand();
    $target_dir = "./img/";
    $target_file = $target_dir . $ran.basename($_FILES["file"]["name"]);
    $filename = $target_file;
    $uploadOk = 1;
    $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
    // Check if image file is a actual image or fake image
    if(isset($_POST["submit"])) {
        $check = getimagesize($_FILES["file"]["tmp_name"]);
        if($check !== false) {
            $uploadOk = 1;
        } else {
            echo "File is not an image.";
            $uploadOk = 1;
        }
    }
	
	if ($_FILES["file"]["size"] > 50000000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }
    // Allow certain file formats
    if($imageFileType != "GIF" && $imageFileType != "JPEG" && $imageFileType != "PNG" && $imageFileType != "JPG" && $imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
    && $imageFileType != "gif" ) {
        $uploadOk = 1;
    }
    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
    // if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
          
        } 
    }
    }

    
    if(isset($_POST["submit"])) {
            $content = mysqli_real_escape_string($con, $_POST['details']);
            $img = $filename;    

            $sql = "INSERT INTO tourist (details,img)";
            $sql .= "VALUES ('$content','$img')";
				
			if (!mysqli_query($con,$sql)) 
			{	
				  die('Could not connect to Database!: ' . mysqli_error($con));
			}
			else
			{
				?>
					<script>
						alert("Tourist Added!");
						document.location.href = "tourist.php";
						
					</script>
				<?php
			}

		}
?>	
